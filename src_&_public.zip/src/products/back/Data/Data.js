const data = {
    productItems:[
    {
        id:"1",
        name:"Beats Headphones",
        price: 999,
        image:"./pics/pictures/h1.jpeg",
    },
    {
        id:"2",
        name:"latest Headphones",
        price: 899,
        image:"./pics/pictures/pic3.jpeg",
    },    
    {
        id:"3",
        name:"Box Headphones",
        price: 11999,
        image:"./pics/pictures/h5.jpeg",
    },
    {
        id:"4",
        name:"Macbook HeadPhones",
        price: 7999,
        image:"./pics/pictures/h12.jpeg",
    },
    {
        id:"5",
        name:"Oneplus",
        price: 7999,
        image:"./pics/pictures/p5.jpeg",
    },
    {
        id:"6",
        name:"Realme",
        price: 7999,
        image:"./pics/pic13.jpeg",
    },
    {
        id:"7",
        name:"Phones",
        price: 7999,
        image:"./pics/pictures/m2.jpeg",
    },
    {
        id:"8",
        name:"New Sale",
        price: 7999,
        image:"./pics/pictures/m3.jpeg",
    },
    
    {
        id:"9",
        name:"Tv",
        price: 27999,
        image:"./pics/pictures/t1.jpeg",
    },
    {
        id:"10",
        name:"Wall Tvs",
        price: 17999,
        image:"./pics/pictures/t11.jpeg",
    },
    {
        id:"11",
        name:" New Trends",
        price: 19999,
        image:"./pics/pictures/t12.jpeg",
    },
    {
        id:"12",
        name:"New Collections",
        price: 17999,
        image:"./pics/pictures/t14.jpeg",
    },
    
    {
        id:"13",
        name:"Acer Laptop",
        price: 4999,
        image:"./pics/pic21.jpeg",
    },
    {
        id:"14",
        name:"Dell Laptop",
        price: 45999,
        image:"./pics/pic22.jpeg",
    },
    {
        id:"15",
        name:"Acer Stock",
        price: 40999,
        image:"./pics/pictures/A1.jpeg",
    },
    {
        id:"16",
        name:"Apple",
        price: 111999,
        image:"./pics/pic24.jpeg",
    },
    {
        id:"17",
        name:"Commercial Washing Machines",
        price: 30999,
        image:"./pics/pictures/w1.jpeg",
    },
    {
        id:"18",
        name:"LG 5 Star Rating Machines",
        price: 20000,
        image:"./pics/pictures/w2.jpeg",
    },
    {
        id:"19",
        name:"Automatic Machines",
        price: 25000,
        image:"./pics/pictures/W3.jpeg",
    },
    {
        id:"20",
        name:"Frnt Load and Top Load Machine",
        price: 28000,
        image:"./pics/pictures/w4.jpeg",
    },
   

]
}

export default data;