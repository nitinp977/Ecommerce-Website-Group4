//import logo from './logo.svg';
//import AdminPanel from "./admin/AdminPanel";
import "./App.css";
//import Home from "./pages/Home";
//import ProductsPage from "./products/ProducsPage";
import Registration from "./pages/Registration";

function App() {
  return (
    <div>
      <Registration/>
    </div>
  );
}

export default App;
