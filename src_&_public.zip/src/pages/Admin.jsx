import React from 'react';


export default function Admin(){
    return(
        <h1>Admin Panel</h1>
    )
}