import React from "react";
import Announcement from "../components/Announcement";
import Footer from "../components/Footer";
import HomeHeader from "../components/HomeHeader";
import Slider from "../components/Slider";

export default function Home() {
  return (
    <div>
      <Announcement />
      <HomeHeader />
      <main>
        <Slider />
        <Footer />
      </main>
    </div>
  );
}
