export const sliderItems = [
  {
    id: 1,
    img: "http://www.pngmart.com/files/16/Portable-Laptop-Top-View-PNG-File.png",
    title: "LAPTOPS",
    desc: " GET FLAT 20% OFF FOR NEW ARRIVALS.",
    bg: "f5fafd",
  },
  {
    id: 2,
    img: "http://blog.amin.org/2011nfl/files/2012/10/1.png",
    title: "HEADPHONES",
    desc: " Min.20% Off",
    bg: "fcf1ed",
  },
  {
    id: 3,
    img: "https://www.nicepng.com/png/detail/922-9229421_apple-watch-repair-in-mahalaxmi-apple-watch-series.png",
    title: "SMART-WATCHES",
    desc: "GET UPTO 20-50% OFF.",
    bg: "fbf0f4",
  },
];
