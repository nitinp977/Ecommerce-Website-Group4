/* eslint-disable no-restricted-globals */
import { Search, ShoppingCartOutlined } from "@material-ui/icons";
import { Badge } from "@material-ui/core";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import React from "react";
import Cart from "../pages/Cart";
import "../styles/styleHeader.css";
import Login from "../pages/Login";

export default function HomeHeader() {
  return (
    <div>
      <Router>
        <div className="header-main">
          <div className="header-wrapper">
            <div className="header-left">
              <h1 style={{ fontWeight: "bold" }}>XYZ.</h1>
            </div>
            <div className="header-center">
              <div className="header-search">
                <input
                  type="text"
                  placeholder="Search for products..."
                  style={{ border: "none", width: "400px", height: "30px" }}
                />
                <Search style={{ color: "white", fontSize: 16 }} />
              </div>
            </div>
            <div className="header-right">
              <Link to="/login">
                <button
                  className="header-menu"
                  style={{
                    backgroundColor: "transparent",
                    border: "none",
                    color: "white",
                  }}
                >
                  {localStorage.getItem("Name")}
                </button>
              </Link>

              <a
                className="header-a"
                href={"www.mylink.com"}
                target="_self"
                rel="noreferrer"
              >
                Logout
              </a>

              <div className="header-menu">
                <Link to="/cart">
                  <button
                    style={{ backgroundColor: "transparent", border: "none" }}
                  >
                    <Badge badgeContent={1} color="primary">
                      <ShoppingCartOutlined />
                    </Badge>
                  </button>
                </Link>
                <Switch>
                  <Route exact path="/cart" component={Cart} />
                  <Route exact path="/login" component={Login} />
                </Switch>
              </div>
            </div>
          </div>
        </div>
      </Router>
    </div>
  );
}
