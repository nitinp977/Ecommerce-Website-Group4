import React from "react";

import "../styles/styleAnnouncement.css";
export default function Announcement() {
  return (
    <div className="announcement-main">
      Super Deal!! Free Shipping on Orders Above ₹2999
    </div>
  );
}